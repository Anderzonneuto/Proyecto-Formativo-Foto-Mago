$(document).ready(function () {
    
    feather.replace();

    
    $('[data-toggle="tooltip"]').tooltip();
    $('[data-toggle="popover"]').popover();

   
    $('a.page-scroll').on('click', function (event) {
        event.preventDefault();
        var target = $(this.getAttribute('href'));
        if (target.length) {
            $('html, body').stop().animate({
                scrollTop: target.offset().top - 50
            }, 800); 
        }
    });

  
    $(window).on('scroll', function () {
        var scroll = $(this).scrollTop();

      
        $('.sticky-navigation').toggleClass('navbar-shadow', scroll >= 100);

        
        $('.scroll-top').toggleClass('active', scroll >= 600);
    });

    
    $('.scroll-top').on('click', function () {
        $('html, body').stop().animate({ scrollTop: 0 }, 800); // 800ms para un desplazamiento más rápido hacia arriba
    });

   
    $('.switcher-trigger').on('click', function () {
        $('.switcher-wrap').toggleClass('active');
    });

   
    $('.color-switcher ul li').on('click', function () {
        var color = $(this).attr('data-color');
        $('#theme-color').attr("href", "css/" + color + ".css");
        $('.color-switcher ul li').removeClass('active');
        $(this).addClass('active');

       
        localStorage.setItem('themeColor', color);
    });

    
    var savedColor = localStorage.getItem('themeColor');
    if (savedColor) {
        $('#theme-color').attr("href", "css/" + savedColor + ".css");
        $('.color-switcher ul li[data-color="' + savedColor + '"]').addClass('active');
    }
});
