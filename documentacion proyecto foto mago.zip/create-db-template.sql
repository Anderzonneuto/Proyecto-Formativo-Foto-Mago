-- Active: 1711925839605@@127.0.0.1@3306
CREATE DATABASE 
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('contact-form');

    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Evita el envío del formulario

        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const message = document.getElementById('message').value;

        alert(`Mensaje enviado por ${name} (${email}): ${message}`);

        // Aquí podrías añadir lógica para enviar los datos a un servidor
        form.reset(); // Limpia el formulario después de enviarlo
    });
});